// أناشيد ونصايح دينية عشوائية للأمر "بوم"
const NASHEEDS = [
    { type: 'audio', url: 'https://ia803403.us.archive.org/17/items/tala3-albadro-alayna/tala3-albadro-alayna.mp3', title: 'طلع البدر علينا' },
    { type: 'audio', url: 'https://ia802905.us.archive.org/9/items/salallah-ala-muhammad/salallah-ala-muhammad.mp3', title: 'صل الله على محمد' },
];

const NASEEHA = [
    '🌙 *نصيحة اليوم*\n\n قال النبي ﷺ:\n*"من صلى الفجر في جماعة فهو في ذمة الله"*\n\n📿 اللهم اجعلنا من المصلين',
    '🌿 *نصيحة اليوم*\n\n قال الله تعالى:\n*"وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ"*\n\n📿 توكل على الله دايماً',
    '☀️ *نصيحة اليوم*\n\n قال النبي ﷺ:\n*"الطهور شطر الإيمان"*\n\n📿 حافظ على وضوئك دايماً',
    '🌟 *نصيحة اليوم*\n\n قال النبي ﷺ:\n*"تبسمك في وجه أخيك صدقة"*\n\n📿 ابتسم لأهلك وأصحابك',
    '🌙 *نصيحة اليوم*\n\n قال النبي ﷺ:\n*"من قرأ آية الكرسي دبر كل صلاة لم يمنعه من دخول الجنة إلا أن يموت"*\n\n📿 لا تنسى آية الكرسي بعد كل صلاة',
    '🕌 *نصيحة اليوم*\n\n قال النبي ﷺ:\n*"اتقوا الله حيثما كنتم وأتبع السيئة الحسنة تمحها"*\n\n📿 الحسنات يذهبن السيئات',
    '💚 *نصيحة اليوم*\n\n قال الله تعالى:\n*"إِنَّ مَعَ الْعُسْرِ يُسْرًا"*\n\n📿 بعد كل ضيقة فرجة باذن الله',
    '🌺 *نصيحة اليوم*\n\n قال النبي ﷺ:\n*"لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه"*\n\n📿 أحب الخير للجميع',
    '✨ *نصيحة اليوم*\n\n قال النبي ﷺ:\n*"من كان يؤمن بالله واليوم الآخر فليقل خيرا أو ليصمت"*\n\n📿 كل كلمة طيبة صدقة',
    '🤲 *نصيحة اليوم*\n\n قال النبي ﷺ:\n*"الدعاء هو العبادة"*\n\n📿 لا تنسى ذكر الله في كل وقت',
];

const handler = async (m, { conn }) => {
    const naseeha = NASEEHA[Math.floor(Math.random() * NASEEHA.length)];

    // جرب تبعت نشيد صوتي + نصيحة
    const nasheed = NASHEEDS[Math.floor(Math.random() * NASHEEDS.length)];
    try {
        await conn.sendMessage(m.chat, {
            audio: { url: nasheed.url },
            mimetype: 'audio/mpeg',
            fileName: nasheed.title + '.mp3',
            contextInfo: {
                externalAdReply: {
                    title: nasheed.title,
                    body: naseeha.split('\n')[0],
                    mediaType: 1
                }
            }
        }, { quoted: m });

        // بعد النشيد ابعت النصيحة
        await conn.sendMessage(m.chat, { text: naseeha }, { quoted: m });
        return;
    } catch {}

    // fallback - نصيحة نصية بس
    await conn.sendMessage(m.chat, { text: naseeha }, { quoted: m });
};

handler.command   = ['بوم'];
handler.usage     = ['بوم'];
handler.usePrefix = false;

export default handler;
